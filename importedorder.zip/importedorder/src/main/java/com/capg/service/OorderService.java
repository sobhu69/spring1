package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.DAO.OrderDao;
import com.capg.entity.Order;

@Service
public class OorderService {
	@Autowired
	OrderDao ords;


	public Order createOrder(Order order) {
		  double price = order.getPrice()*75;
	        order.setPrice(price);
		  double amount = order.getQuantity()*price;
			order.setAmount(amount);
			double charges = amount*(1.25)/100;
			order.setCharges(charges);
		// TODO Auto-generated method stub
		return ords.createOrder(order);
	}

	
	public List<Order> viewAllOrders() {
		// TODO Auto-generated method stub
		return ords.viewAllOrders();
	}

	
	public Order updateOrder(Order order) {
		// TODO Auto-generated method stub
		return ords.updateOrder(order);
	
	}

	
	public List<Order> viewByQuantity(int quantity1, int quantity2) {
		// TODO Auto-generated method stub
		return ords.viewByQuantity(quantity1, quantity2);
		
	}

	
	public List<Order> greaterThanAmount(double amount) {
		// TODO Auto-generated method stub
		return ords.greaterThanAmount(amount);
	}
	
	

}
