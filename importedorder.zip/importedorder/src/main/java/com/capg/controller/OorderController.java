package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.entity.Order;
import com.capg.service.OorderService;


@RestController
public class OorderController {
	@Autowired
	OorderService ordc;
	
	
	// Add Order Details
	   @PostMapping(value="/create")
	   public Order createOrder(@RequestBody Order order) {
		 return ordc.createOrder(order);
	  }
	
	
	   // Getting All Orders Detail  
		@GetMapping(value="/viewall")
		public List<Order> viewAllOrders() {
			
			return ordc.viewAllOrders();
		}
		
		//Update Order Details
		 @PutMapping(value="update")
		 public Order updateOrder( Order order) {
			 return ordc.updateOrder(order);
		 }
		 
		//Getting Orders by Quantity Range 
		 @RequestMapping(value="/orderrange/{quantity}/{quantity}")
			List<Order> viewByQuantity(@PathVariable int quantity1, @PathVariable int quantity2) {
				return ordc.viewByQuantity(quantity1, quantity2);
			}
    
		 @RequestMapping(value="/gamount/{amount}")
			List<Order> greaterThanAmount(@PathVariable double amount){
				return ordc.greaterThanAmount(amount);
			} 

}
