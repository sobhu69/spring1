package com.capg.DAO;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capg.entity.Order;

@Repository
@Transactional
public class OrderDaoImpl implements OrderDao {

	@Autowired
	OrderRepoDao ord;
	
	@Override
	public Order createOrder(Order order) {
		// TODO Auto-generated method stub
		
		return ord.save(order);
	}

	@Override
	public List<Order> viewAllOrders() {
		// TODO Auto-generated method stub
		
		return ord.findAll();
	}

	@Override
	public Order updateOrder(Order order) {
		// TODO Auto-generated method stub
		
		return ord.save(order);
	}

	@Override
	public List<Order> viewByQuantity(int quantity1, int quantity2) {
		// TODO Auto-generated method stub
		return ord.viewByRange(quantity1, quantity2);
	}

	@Override
	public List<Order> greaterThanAmount(double amount) {
		// TODO Auto-generated method stub
		return ord.viewByGreater(amount);
	}

}
