package com.capg.DAO;

import java.util.List;

import com.capg.entity.Order;


public interface OrderDao {

	Order createOrder(Order order);

	List<Order> viewAllOrders();

	Order updateOrder(Order order);

	List<Order> viewByQuantity(int quantity1, int quantity2);

	List<Order> greaterThanAmount(double amount);
}
