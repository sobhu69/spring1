package com.opaline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImportedorderApplicationTests {

	@Test
	void contextLoads() {
	}

}
