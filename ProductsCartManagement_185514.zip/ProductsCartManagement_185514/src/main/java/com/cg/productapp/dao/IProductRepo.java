package com.cg.productapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.productapp.bean.Product;

//DAO interface
@Repository
public interface IProductRepo  extends JpaRepository<Product, String>{

}
