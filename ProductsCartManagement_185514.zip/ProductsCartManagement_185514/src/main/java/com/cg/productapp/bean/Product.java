package com.cg.productapp.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
/***
 *Author:Y.Srilekha
 *Date of Creation:30/7/2019
 *MethodName:BeanClass
 *parameters:product parameters
 *return value:null
 *purpose:creation of Product class
 */

@Entity                    //Bean class is declared as Entity class
public class Product {
	@Id                   //Id is taken as Primary Key
private String id;          
private String name;
private String model;
private double price;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getModel() {
	return model;
}
public void setModel(String model) {
	this.model = model;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
@Override
public String toString() {
	return "Product [id=" + id + ", name=" + name + ", model=" + model + ", price=" + price + "]";
}

}
