package com.cg.productapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductsCartManagement185514Application {

	public static void main(String[] args) {
		SpringApplication.run(ProductsCartManagement185514Application.class, args);
	}

}
