package com.capg.MainDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capg.Register.UserRegister;
import com.capg.utils.DBconfig;
//import com.capg.utils.Dbconfig;
//import com.capg.utils.Dbconfig;

public class MainDAO {
	
	public void saveUserDetail() throws SQLException{
		Connection con = DBconfig.getConnection();
		Statement st = con.createStatement();
		PreparedStatement s1 = con.prepareStatement("insert into flight_details values(?,?,?,?)");
		//s1.setInt(1,UserRegister.getBookid());
		//s1.setString(2,.getBooktitle());
		//s1.setString(3,book.getBookdesc());
		//s1.executeUpdate();
		//System.out.println("done");
	}
	public void searchFlight(int flight_id) throws SQLException{
		Connection con = DBconfig.getConnection();
		Statement st = con.createStatement();
		//ResultSet rs = st.executeQuery("'select * from flight_details where flight_id='+flight_id ");
	}
	public void bookFlight() throws SQLException{
		Connection con = DBconfig.getConnection();
	}
	public void cancelFlight() throws SQLException{
		Connection con = DBconfig.getConnection();
	}
	public void viewFlight() throws SQLException{
		Connection con = DBconfig.getConnection();
	}
	
	

}
